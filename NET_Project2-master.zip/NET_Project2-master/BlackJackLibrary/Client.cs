﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BlackJackLibrary
{
    [DataContract]
    public  class Client
    {
        [DataMember]
        public uint ClientID { get; set; }
        [DataMember]
        public uint ScoreboardPoints { get; set; }
        [DataMember]
        public uint TotalPoints { get; set; }
        [DataMember]
        public string ClientName { get; set; }
        [DataMember]
        public bool isSomeonesTurn;

        public Client(uint clientID, uint scoreboardPoints, uint totalPoints, string clientName)
        {
            ClientID = clientID;
            ScoreboardPoints = scoreboardPoints;
            TotalPoints = totalPoints;
            ClientName = clientName;
        }
    }
}
